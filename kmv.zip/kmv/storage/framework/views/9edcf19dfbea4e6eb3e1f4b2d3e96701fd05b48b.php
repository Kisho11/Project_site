<div class="footer-wrap" style="background:#FFFFFF;">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="footer_logo"><img alt="" class="footer-default" src="web/assets/images/main/kmv-logo-title.png"></div>
        <p>Lorem ipsum dolor sit amet, adipiscing elit. Sed tempor, urna eu scelerisque maximus, urna nibh semper lectus, ut interdum nunc ligula et magna. In ac mauris vehicula, vulputate sem at, placerat nisl. Etiam laoreet erat magna, at hendrerit lorem vulputate non. Nam facilisis congue convallis.</p>
      </div>
      <div class="col-lg-3 col-md-3">
        <h3>Quick links</h3>
        <ul class="footer-links">
          <li> <a href="index.html">Home</a></li>
          <li> <a href="about.html">About</a></li>
          <li> <a href="classes.html">News & Events</a></li>
          <li> <a href="teachers.html">Achievements</a></li>
          <li> <a href="testimonials.html">Gallery</a></li>
          <li> <a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
      
      <div class="col-lg-3 col-md-4">
        <div class="footer_info">
          <h3>Get in Touch</h3>
          <ul class="footer-adress">
            <li class="footer_address"> <i class="fas fa-map-signs"></i> <span> Vilson Road, Kilinochchi, Sri Lanka.</span> </li>
            <li class="footer_email"> <i class="fas fa-envelope" aria-hidden="true"></i> <span><a href="mailto:info@example.com"> kilinochchimv@yahoo.com </a></span> </li>
            <li class="footer_phone"> <i class="fas fa-phone-alt"></i> <span><a href="tel:7704282433"> +94 21 2285 414</a></span> </li>
          </ul>
          <div class="social-icons footer_icon">
            <ul>
              <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH E:\KMV\OBA\WEB DEV\Projects\kmv\resources\views/layouts/web/includes/footer.blade.php ENDPATH**/ ?>