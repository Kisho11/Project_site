<?php
  $title = "Coming Soon";
?>


<?php $__env->startSection('content'); ?>



<!-- Inner Content Start -->
<div class="innerContent-wrap">
  <div class="container"> 
    
    <!-- 404 Start -->
    <div class="404-wrap">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="four-zero-page">
            <h2 style="color: #481210;font-size: 100px;">COMING SOON</h2>
            <h3 style="color: #481210;">We are still in development mode</h3>
            <div class="readmore"> <a href="<?php echo e(route('index')); ?>">Go To Homepage</a> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 404 End --> 
    
  </div>
</div>
<!-- Inner Content Start --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KMV\OSA\WEB DEV\Projects\kmv\resources\views/page/web/comingsoon.blade.php ENDPATH**/ ?>