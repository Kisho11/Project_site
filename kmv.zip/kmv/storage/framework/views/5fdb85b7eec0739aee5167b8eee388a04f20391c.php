<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Fav Icon -->
<link rel="shortcut icon" href="web/assets/images/main/kmv-logo.jpg">

<!-- Bootstrap CSS -->
<link href="/web/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/web/assets/css/all.css" rel="stylesheet">
<link href="/web/assets/css/owl.carousel.css" rel="stylesheet">

<link href="/web/assets/rs-plugin/css/settings.css" rel="stylesheet">

<!-- Jquery Fancybox CSS -->
<link href="/web/assets/css/jquery.fancybox.min.css"  type="text/css"media="screen" />
<link href="/web/assets/css/animate.css" rel="stylesheet">
<link href="/web/assets/css/style.css" rel="stylesheet"  id="colors">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<title>KMV</title>
<style>
    .footer-wrap p, .footer-links li a, .footer-adress li span a, .footer-adress li span,
    .footer-wrap h3, .footer-adress li > i
    {
        color: #500d0a !important;
    }
</style>
</head><?php /**PATH E:\KMV\OBA\WEB DEV\Projects\kmv\resources\views/layouts/web/includes/title.blade.php ENDPATH**/ ?>