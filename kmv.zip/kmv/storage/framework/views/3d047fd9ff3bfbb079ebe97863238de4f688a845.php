<!doctype html>
<html lang="en">
<?php echo $__env->make('layouts.web.includes.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<!--Header Start-->
<?php echo $__env->make('layouts.web.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header End--> 


<!-- Begin Page Content -->
<div class="container-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<!-- /.container-fluid -->

<!-- Footer Start -->
<?php echo $__env->make('layouts.web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer End --> 

<!-- Bottom Start -->
<?php echo $__env->make('layouts.web.includes.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Bottom End -->
</body>
</html><?php /**PATH E:\KMV\OSA\WEB DEV\Projects\kmv\resources\views/layouts/web/app.blade.php ENDPATH**/ ?>