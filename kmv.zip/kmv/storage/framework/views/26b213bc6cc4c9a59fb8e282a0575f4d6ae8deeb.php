

<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KMV\OBA\WEB DEV\Projects\kmv\resources\views/page/dashboard.blade.php ENDPATH**/ ?>