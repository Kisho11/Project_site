<?php
  $title = "Home";
?>


<?php $__env->startSection('content'); ?>

<style>
  p
  {
    text-align: justify;
  }

  .cours-title
  {
    min-height: 290px;
  }

  .event-img
  {
    width: 370px !important;
    height:250px !important;
  }
</style>

<!-- Revolution slider start -->
<div class="tp-banner-container">
  <div class="tp-banner">
    <ul>
      <li data-slotamount="7" data-transition="3dcurtain-horizontal" data-masterspeed="1000" data-saveperformance="on"> 
        <img alt="" src="web/assets/images/dummy.png" data-lazyload="web/assets/images/main/slider-1.png">
        <div class="caption lft large-title tp-resizeme slidertext2" data-x="center" data-y="170" data-speed="600" data-start="1600">
         <span> Empowering Students with Excellence in Education, Culture, and Innovation in the Heart of Kilinochchi. </span>
        </div>
        <div class="caption lfb large-title tp-resizeme slidertext3" data-x="center" data-y="260" data-speed="600" data-start="2200"> 
          Established in 1927, our school has a proud tradition of fostering leadership and excellence, shaping the pillars of our community.
        </div>
      </li>
      <li data-slotamount="7" data-transition="slotzoom-horizontal" data-masterspeed="1000" data-saveperformance="on"> 
        <img alt="" src="web/assets/images/dummy.png" data-lazyload="web/assets/images/main/slider-2.png">
        <div class="caption lft large-title tp-resizeme slidertext2" data-x="center" data-y="170" data-speed="600" data-start="1600">
          <span> International School </span>
        </div>
        <div class="caption lfb large-title tp-resizeme slidertext3" data-x="center" data-y="260" data-speed="600" data-start="2200"> 
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur, 
          <br/>
          pulvinar rhoncus risus. Fusce vel rutrum mi. Suspendisse pretium tellus eu ipsum.
        </div>
      </li>
      <li data-slotamount="7" data-transition="slotzoom-horizontal" data-masterspeed="1000" data-saveperformance="on"> 
        <img alt="" src="web/assets/images/dummy.png" data-lazyload="web/assets/images/main/slider-3.png">
        <div class="caption lft large-title tp-resizeme slidertext2" data-x="center" data-y="170" data-speed="600" data-start="1600">
          <span> International School </span>
        </div>
        <div class="caption lfb large-title tp-resizeme slidertext3" data-x="center" data-y="260" data-speed="600" data-start="2200"> 
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur, 
          <br/>
          pulvinar rhoncus risus. Fusce vel rutrum mi. Suspendisse pretium tellus eu ipsum.
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- Revolution slider end --> 

<!-- School Vision,Mission & Moto Start -->
<div class="our-course-categories-two ">
  <div class="container">
    <div class="categories_wrap">
      <ul class="row unorderList">
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;">
            <div class="item-inner">
              <div class="cours-title">
                <h4>Our Vision</h4>
                <p>
                  At Kilinochchi Maha Vidyalayam, our vision is to empower students through a comprehensive
                  education that fosters academic excellence, physical well-being, cultural enrichment, and
                  innovative thinking. We are dedicated to nurturing responsible, skilled, and enlightened individuals
                  who will contribute positively to society and thrive in an ever-changing world.
                </p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;">
            <div class="item-inner">
              <div class="cours-title">
                <h4>Our Mission</h4>
                <p>
                  Our mission is to be a leading educational institution in Kilinochchi, renowned for a learning
                  environment that cultivates the potential of every student, encourages lifelong learning, and
                  promotes respect for diversity and community values. We aspire to shape future generations who
                  are not only academically accomplished but also compassionate and globally minded citizens.
                </p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;" >
            <div class="item-inner">
              <div class="cours-title">
                <h4>Our Moto</h4>
                <p>
                  Empowering Minds, Enriching Lives, Shaping Futures
                </p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        
      </ul>
    </div>
  </div>
</div>
<!-- School Vision,Mission & Moto End --> 

<!-- School Description Start -->
<div class="choice-wrap ">
  <div class="container">
    <div class="title">
      <h1>We Are The Best <span>Choice For Your Child</span></h1>
    </div>
    <p style="text-align:justify;">
      Established in 1927, our school has a storied tradition of cultivating leaders and visionaries who
      make significant contributions to our district and beyond. As a 1AB grade institution, we offer a
      comprehensive educational journey from Grade 1 to Grade 13, accommodating a diverse array of
      student interests and aspirations. At the GCE Advanced Level, we provide specialized streams in
      Biology, Mathematics, Arts, and Commerce, equipping students with the knowledge and skills to
      excel in their chosen fields.
    </p>
    <div class="readmore"><a href="#">Read More</a></div>
  </div>
</div>
<!-- School Description End -->


<!-- Principal Start  -->
<div class="innerContent-wrap">
  <div class="container"> 
    
    <!-- Teachers Start -->
    <!-- 
    <div class="classDetails-wrap">
      <div class="row">
        <div class="col-lg-4">
          <div class="teacher_left">
            <div class="teacher_delImg"> <img src="web/assets/images/main/principal.png" alt="Image"></div>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="teacher_del ">
            <h3>Mrs. Ilaventhi Nirmalaraj</h3>
            <div class="designation">Principle</div>
            <p style="text-align:justify;">
              At the helm of Kilinochchi Maha Vidyalayam is Mrs. Ilaventhi Nirmalaraj, a visionary leader and an
              advocate for holistic educational excellence. With a Master's Degree in Educational
              Administration and a Bachelor's in Science Education, Mrs. Nirmalaraj brings a wealth of
              knowledge and an unwavering commitment to fostering a nurturing and dynamic learning
              environment.
            </p>
            <div class="readmore"><a href="#">Read More</a></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Teachers End --> 
    
  </div>
</div>
<!-- Principal Start --> 

<!-- New & Events Start -->
<div class="class-wrap" style="background:#481210;">
  <div class="container">
    <div class="title">
      <h1> News & Events</h1>
    </div>
    <ul class="owl-carousel  ">
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img class="event-img" src="web/assets/images/main/news-thumb-1.jpg" alt="">
            <div class="time_box"><span>2024-04-01</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Colours Night 2023.</a></h3>
            <p>Outstanding Athletic Achievements awarded at the 2023 Colours Night.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img class="event-img" src="web/assets/images/main/news-thumb-3.jpg" alt="">
            <div class="time_box"><span>2024-04-01</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">U-17 Cricket Tournament Cup.</a></h3>
            <p>Kilinochchi Maha Vidyalayam's U-17 Cricket Team Wins Tournament Cup.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img class="event-img" src="web/assets/images/main/news-thumb-2.jpg" alt="">
            <div class="time_box"><span>2024-04-01</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Prize Day Ceremony 2023</a></h3>
            <p>Dazzling Achievements Unveiled at 2023 Prize Day Ceremony.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- New & Events End --> 

<!-- Achievements Start -->
<div class="blog-wrap flight-wrap ">
  <div class="container">
    <div class="title">
      <h1> Achievements </h1>
    </div>
    <ul class="row unorderList">
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog1.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Education Programs</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor gravida.</p>
          </div>
        </div>
      </li>
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog2.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Games Program</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur.</p>
          </div>
        </div>
      </li>
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog3.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Labs Programs</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur.</p>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- Achievements End --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KMV\OSA\WEB DEV\Projects\kmv\resources\views/page/index.blade.php ENDPATH**/ ?>