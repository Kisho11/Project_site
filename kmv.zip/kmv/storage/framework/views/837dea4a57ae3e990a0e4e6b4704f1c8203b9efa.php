<div class="header-wrap">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-5 col-md-12 navbar-light">
        <div class="logo"> <a href="index.html"><img alt="" class="logo-default" src="web/assets/images/main/kmv-logo-title.png"></a></div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      </div>
      <div class="col-lg-5 col-md-12">
        <div class="navigation-wrap" id="filters">
          <nav class="navbar navbar-expand-lg navbar-light"> <a class="navbar-brand" href="#">Menu</a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <button class="close-toggler" type="button" data-toggle="offcanvas"> <span><i class="fas fa-times-circle" aria-hidden="true"></i></span> </button>
              <ul class="navbar-nav mr-auto">
                <li class="nav-item"> <a class="nav-link active"  href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a> </li>
                <li class="nav-item"><a class="nav-link" href="classes.html">About</a> <i class="fas fa-caret-down"></i>
                  <ul class="submenu">
                    <li><a href="classes.html">History</a></li>
                    <li><a href="classes-details.html">Overview</a></li>
                    <li><a href="classes.html">Administration</a></li>
                    <li><a href="classes.html">Past Principals</a></li>
                    <li><a href="classes.html">Principal's message</a></li>
                  </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="classes.html">News & Events</a> <i class="fas fa-caret-down"></i>
                  <ul class="submenu">
                    <li><a href="classes.html">News</a></li>
                    <li><a href="classes-details.html">Events</a></li>
                  </ul>
                </li>
                <li class="nav-item"><a class="nav-link"  href="">Achievements</a>
                 
                </li>
                <li class="nav-item"><a class="nav-link" href="#.">Gallery</a> <i class="fas fa-caret-down"></i>
                  
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
      <div class="col-lg-2">
        <div class="header_info">
          <div class="loginwrp"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH E:\KMV\OBA\WEB DEV\Projects\kmv\resources\views/layouts/web/includes/header.blade.php ENDPATH**/ ?>