

<?php $__env->startSection('content'); ?>

<!-- Revolution slider start -->
<div class="tp-banner-container">
  <div class="tp-banner">
    <ul>
      <li data-slotamount="7" data-transition="3dcurtain-horizontal" data-masterspeed="1000" data-saveperformance="on"> 
        <img alt="" src="web/assets/images/dummy.png" data-lazyload="web/assets/images/slider1.jpg">
        <div class="caption lft large-title tp-resizeme slidertext2" data-x="center" data-y="170" data-speed="600" data-start="1600">
          <span> Education Bright Future </span>
        </div>
        <div class="caption lfb large-title tp-resizeme slidertext3" data-x="center" data-y="260" data-speed="600" data-start="2200"> 
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur, 
          <br/>
          pulvinar rhoncus risus. Fusce vel rutrum mi. Suspendisse pretium tellus eu ipsum.
        </div>
      </li>
      <li data-slotamount="7" data-transition="slotzoom-horizontal" data-masterspeed="1000" data-saveperformance="on"> 
        <img alt="" src="web/assets/images/dummy.png" data-lazyload="web/assets/images/slider.jpg">
        <div class="caption lft large-title tp-resizeme slidertext2" data-x="center" data-y="170" data-speed="600" data-start="1600">
          <span> International School </span>
        </div>
        <div class="caption lfb large-title tp-resizeme slidertext3" data-x="center" data-y="260" data-speed="600" data-start="2200"> 
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur, 
          <br/>
          pulvinar rhoncus risus. Fusce vel rutrum mi. Suspendisse pretium tellus eu ipsum.
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- Revolution slider end --> 

<!-- School Start -->
<div class="our-course-categories-two ">
  <div class="container">
    <div class="categories_wrap">
      <ul class="row unorderList">
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;">
            <div class="item-inner">
              <div class="cours-icon"> <span class="coure-icon-inner"> <img src="images/teacher.png" alt=""> </span> </div>
              <div class="cours-title">
                <h4>Our Vision</h4>
                <p>Lorem ipsum dolor sit amet, adipiscing elit. Vivamus nibh dolor gravida at eleifend</p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;">
            <div class="item-inner">
              <div class="cours-icon"> <span class="coure-icon-inner"> <img src="images/book.png" alt=""> </span> </div>
              <div class="cours-title">
                <h4>Our Mission</h4>
                <p>Lorem ipsum dolor sit amet, adipiscing elit. Vivamus nibh dolor gravida at eleifend</p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        <li class="col-lg-4 col-md-12"> 
          <!-- single-course-categories -->
          <div class="categories-course" style="background:#500d0a !important;" >
            <div class="item-inner">
              <div class="cours-icon"> <span class="coure-icon-inner"> <img src="images/support.png" alt=""> </span> </div>
              <div class="cours-title">
                <h4>Our Moto</h4>
                <p>Lorem ipsum dolor sit amet, adipiscing elit. Vivamus nibh dolor gravida at eleifend</p>
              </div>
            </div>
          </div>
          <!--// single-course-categories --> 
        </li>
        
      </ul>
    </div>
  </div>
</div>
<!-- School End --> 

<!-- Choice Start -->
<div class="choice-wrap ">
  <div class="container">
    <div class="title">
      <h1>We Are The Best <span>Choice For Your Child</span></h1>
    </div>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam at eleifend est. Donec dictum at diam ut finibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam diam magna, condimentum in nibh sed, mattis fermentum diam.</p>
    <div class="readmore"><a href="#">Read More</a></div>
  </div>
</div>
<!-- Choice End -->


<!-- Inner Content Start -->
<div class="innerContent-wrap">
  <div class="container"> 
    
    <!-- Teachers Start -->
    <div class="classDetails-wrap">
      <div class="row">
        <div class="col-lg-4">
          <div class="teacher_left">
            <div class="teacher_delImg"> <img src="web/assets/images/teacher.png" alt="Image"></div>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="teacher_del ">
            <h3>Stella Roffin</h3>
            <div class="designation">Art teacher</div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc bibendum dui metus, vitae auctor nibh tincidunt pulvinar. Integer id arcu sed orci mollis tincidunt. Aliquam quis aliquet arcu, sit amet lobortis lectus. Nam et lorem et turpis malesuada auctor. Fusce a diam eget neque porta porta. Maecenas sit amet viverra lacus. Nam aliquam semper leo a interdum.</p>
            <p>Nunc pretium nec lectus venenatis mattis. Pellentesque accumsan iaculis tristique. Aliquam sagittis lacinia eros, sed rutrum lectus semper non. Donec imperdiet auctor arcu ut sollicitudin. Sed tincidunt, erat a condimentum ornare, purus nunc pulvinar justo, in porta dolor nisi et est. Nullam quis mollis mauris. Donec sed ex non erat vehicula elementum. Duis luctus laoreet justo, vel vehicula sapien gravida ut. Quisque gravida et ex a venenatis. Morbi vitae ullamcorper velit. Ut vel arcu elementum, blandit tellus vel, cursus lacus. Sed ornare, nulla ac gravida maximus, erat velit laoreet sapien, in elementum mi risus in lectus.</p>
            <div class="readmore"><a href="#">Read More</a></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Teachers End --> 
    
  </div>
</div>
<!-- Inner Content Start --> 

<!-- Classes Start -->
<div class="class-wrap" style="background:#481210;">
  <div class="container">
    <div class="title">
      <h1> News & Events</h1>
    </div>
    <ul class="owl-carousel  ">
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img src="web/assets/images/education_img.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Education Programs System</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img src="web/assets/images/kid_game.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Games Program held in a Week</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
      <li class="item">
        <div class="class_box">
          <div class="class_Img"><img src="web/assets/images/lab.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Labs Programs</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor adipiscing consectetur.</p>
            <div class="students_box">
              <div class="students">Students: 30</div>
              <div class="stud_fee">Fee: $150</div>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- Classes End --> 

<!-- Blog Start -->
<div class="blog-wrap flight-wrap ">
  <div class="container">
    <div class="title">
      <h1> Achievements </h1>
    </div>
    <ul class="row unorderList">
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog1.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Education Programs</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor gravida.</p>
          </div>
        </div>
      </li>
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog2.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Games Program</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur.</p>
          </div>
        </div>
      </li>
      <li class="col-lg-4">
        <div class="blog_box">
          <div class="blogImg"><img src="web/assets/images/blog3.jpg" alt="">
            <div class="time_box"><span>08:00 am - 10:00 am</span></div>
          </div>
          <div class="path_box">
            <h3><a href="#">Labs Programs</a></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nibh dolor, gravida faucibus dolor consectetur.</p>
          </div>
        </div>
      </li>
    </ul>
  </div>
</div>
<!-- Blog End --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KMV\OBA\WEB DEV\Projects\kmv\resources\views/page/index.blade.php ENDPATH**/ ?>