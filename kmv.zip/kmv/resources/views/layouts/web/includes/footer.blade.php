<div class="footer-wrap" style="background:#fff6af;">
  <div class="container">
    <div class="row">
      <div class="col-lg-5">
        <div class="footer_logo"><img alt="" class="footer-default" src="web/assets/images/main/kmv-logo-title.png"></div>
        <p>
        Established in 1927, our 1AB grade school cultivates leaders and visionaries from Grade 1 to Grade 13, offering comprehensive education.
      </p>
      </div>
      
      <div class="col-lg-3 col-md-3">
        <h3>Quick links</h3>
        <ul class="footer-links">
          <li> <a href="index.html">Home</a></li>
          <li> <a href="classes.html">News & Events</a></li>
          <li> <a href="teachers.html">Achievements</a></li>
          <li> <a href="testimonials.html">Gallery</a></li>
          <li> <a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
      
      <div class="col-lg-4 col-md-4">
        <div class="footer_info">
          <h3>Get in Touch</h3>
          <ul class="footer-adress">
            <li class="footer_address"> <i class="fas fa-map-signs"></i> <span> Wilson Road, Kilinochchi, Sri Lanka.</span> </li>
            <li class="footer_email"> <i class="fas fa-envelope" aria-hidden="true"></i> <span><a href="mailto:info@example.com"> kilinochchimv@yahoo.com </a></span> </li>
            <li class="footer_phone"> <i class="fas fa-phone-alt"></i> <span><a style="font-size:14px !important;font-weight:normal;" href="tel:7704282433"> +94 21 2285 414</a></span> </li>
          </ul>
          <div class="social-icons footer_icon">
            <ul>
              <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
              <!--
              <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>
              -->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>